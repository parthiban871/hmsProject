package com.hospital.utils;

public enum Entity {
	
	Admin,Doctor,Nurse,Lab,Xray,Pharmatiest,Receptioniest,Accountant;

}
