package com.hospital.entities;

import java.util.List;

import com.hospital.models.Employee;
import com.hospital.models.EmployeeStatatistic;

public interface AccountantDAO extends EmployeeDAO{
	

	
	

}
